//KRISHNAMURTI OR ROBINSON OR STRONG NO.
#include<stdio.h>
int main(){
	int n,temp,r,fact,sum=0;
	printf("Enter a num to check strong num or not: ");
	scanf("%d",&n);
	temp=n;
	while(n>0){
		r=n%10;
		fact=1;
		while(r>0){
			fact=fact*r;
			r--;
		}
		sum=sum+fact;
		n=n/10;
	}
	n=temp;
	if(n==sum){
		printf("STRONG NO.");
	}
	else{
		printf("NOT A STRONG NO.");
	}
}
