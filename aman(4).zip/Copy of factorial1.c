//FACTORIAL 
#include<stdio.h>
int main(){
	int n,fact=1,temp;
	printf("Enter a num to find factorial: ");
	scanf("%d",&n);
	temp=n;
	while(n>0){
		fact=fact*n;
		n--;
	}	
	
	printf("The factorial of %d is: %d",temp,fact);
}

