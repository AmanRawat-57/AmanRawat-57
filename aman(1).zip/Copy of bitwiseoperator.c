//BITWISE OPERATORS
#include <stdio.h>
int main(){
	int a,b;
	printf("Enter the value of a: ");
	scanf("%d",&a);
	printf("Enter the value of b: ");
	scanf("%d",&b);
	printf("\nBITWISE AND %d ",a&b);
	printf("\nBITWISE OR %d ",a|b);
	printf("\nBITWISE XOR %d ",a^b);
}
