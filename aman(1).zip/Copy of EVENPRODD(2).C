//CHECKING NO. IS EVEN OR ODD
#include <stdio.h>
int main(){
	int n;
	printf("Enter a no. to checK even or odd: ");
	scanf("%d",&n);
	if(n&1){
		printf("ODD");
	}
	else{
		printf("EVEN");
	}
}
