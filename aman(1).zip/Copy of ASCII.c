//ASCII VALUE FINDING 
#include <stdio.h>
int main(){
	int n;
	printf("Enter a no.: ");
	scanf("%c",&n);
	printf("%d",n);
	
}
